package ServiceSOAP;

import java.util.List;

import jakarta.jws.WebMethod;
import jakarta.jws.WebService;
import model.Produit;

@WebService
public interface ProduitService {

    @WebMethod
    void addPerson(Produit person);

    @WebMethod
    Produit getPerson(int id);

    @WebMethod
    List<Produit> getAllPersons();

    @WebMethod
    void updatePerson(Produit person);

    @WebMethod
    void deletePerson(int id);
}
