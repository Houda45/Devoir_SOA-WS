package ServiceSOAP;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
//import java.util.Map;
import java.util.Map;

import jakarta.jws.WebService;
import model.Produit;

@WebService(endpointInterface = "ServiceSOAP.PersonService")
public class ProduitServiceImpl implements ProduitService {

    private Map<Integer, Produit> persons = new HashMap<>();
    private int idCounter = 1;

    @Override
    public void addPerson(Produit person) {
        person.setId(idCounter++);
        persons.put(person.getId(), person);
    }

    @Override
    public Produit getPerson(int id) {
        return persons.get(id);
    }

    @Override
    public List<Produit> getAllPersons() {
        return new ArrayList<>(persons.values());
    }

    @Override
    public void updatePerson(Produit person) {
        if (persons.containsKey(person.getId())) {
            persons.put(person.getId(), person);
        }
    }

    @Override
    public void deletePerson(int id) {
        persons.remove(id);
    }

	
}
