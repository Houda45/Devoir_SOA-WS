# personnevsc
Ce projet consiste à créer un service web SOAP simple pour effectuer une opération d'addition en tant que projet initial dans le cadre du cours sur l'Architecture Orientée Services (SOA) pour le programme de Master en Systèmes d'information (SI) à la Faculté des Sciences et Techniques (FST) de l'Université de Noukchott (UN).
