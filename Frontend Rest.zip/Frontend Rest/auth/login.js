let farms = [];
let farmsOriginal = [];
let sortDirection = false;
let currentIndex = -1;
let urlBe = "http://localhost:8080/tp3Jpa/api/Admin";
getPerson();

async function getPerson() {
    persons = [];
    personsOriginal = [];
    let urlBe = "http://localhost:8080/tp3Jpa/api/Admin";
    fetch(urlBe)
        .then(response => response.json())
        .then(data => {
            console.log(data)
            for (let i = 0; i < data.length; i++) {
                let person =
                    {
                        id : data[i].a_id,
                        firstName: data[i].a_nom,
                        lastName: data[i].a_mobile,
                        gender: data[i].a_email,
                        genderr: data[i].a_username,
                        genderrr: data[i].a_password
                    }
                persons.push(person);
                personsOriginal = persons;
            }

            console.log("persons === ", persons)
        });


}

async function enregistrer() {

    let firstName = document.getElementById("a_nom").value;
    let lastName = document.getElementById("a_mobile").value;
    let gender = document.getElementById("a_email").value;
    let genderr = document.getElementById("a_username").value;
    let genderrr = document.getElementById("a_password").value;
    let method = 'GET';
    let person =
        {
            a_nom: firstName,
            a_mobile: lastName,
            a_email: gender,
            a_username: genderr,
            a_password: genderrr
        }

    const response = await fetch(urlBe, {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(person)
    });
    //const data = await response.json();
    resetForm();
}
