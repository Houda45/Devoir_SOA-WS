let farms = [];
let farmsOriginal = [];
let sortDirection = false;
let currentIndex = -1;
let urlBe = "http://localhost:8080/tp3Jpa/api/Admin/Produit";
getPersons();

//draw table then show async

async function getPersons() {
    persons = [];
    personsOriginal = [];
    let urlBe = "http://localhost:8080/tp3Jpa/api/Admin/Produit";
    fetch(urlBe)
        .then(response => response.json())
        .then(data => {
            console.log(data)
            for (let i = 0; i < data.length; i++) {
                let person =
                    {
                        id : data[i].p_id,
                        firstName: data[i].p_nom,
                        lastName: data[i].p_prix,
                        genderrr: data[i].p_image,
                        gender: data[i].p_quantite,
                        genderr: data[i].p_disponible,
                        genderrrr: data[i].p_desc,
                        
                    }
                persons.push(person);
                personsOriginal = persons;
                drawTbl();
            }

            console.log("persons === ", persons)
        });


}

function drawTbl() {
    let tblBody = document.getElementById("body");
    tblBody.innerHTML = "";
    let i = 0;
    persons.forEach(person => {
        id=person.id;
        srcimage=person.genderrr;
        let div = document.createElement("div")
        div.className = 'column';
        let Nomlabel = document.createElement("label")
        Nomlabel.innerText = person.firstName
        div.appendChild(Nomlabel);
        let BR = document.createElement("BR")
        div.appendChild(BR);

        let Image = document.createElement("img")
        Image.src =srcimage;
        Image.class="card-image-top";
        div.appendChild(Image);

        let B = document.createElement("BR")
        div.appendChild(B);

        const text = document.createTextNode("Prix: ");
        div.appendChild(text);
        
        let Prixlabel = document.createElement("label")
        Prixlabel.innerText = person.lastName
        div.appendChild(Prixlabel);
        const espace = document.createTextNode("MRO     ");
        espace.style="color:black";
        div.appendChild(espace);
        
        var a = document.createElement("a")
        a.text="Details";
        a.style="text-decoration:none;";
        a.href = "Details.html?id="+id;
        div.appendChild(a);

        tblBody.appendChild(div);
        i++;
    });
}
var str =window.location.href;
var url = new URL(str);
var idadmin = url.searchParams.get("id");
localStorage.setItem('ok', JSON.stringify(idadmin));