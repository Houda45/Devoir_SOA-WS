let farms = [];
let farmsOriginal = [];
let sortDirection = false;
let currentIndex = -1;
let urlBe = "http://localhost:8080/tp3Jpa/api/Admin/Commande";
getPersons();

//draw table then show async

async function getPersons() {
    persons = [];
    personsOriginal = [];
    let urlBe = "http://localhost:8080/tp3Jpa/api/Admin/Commande";
    fetch(urlBe)
        .then(response => response.json())
        .then(data => {
            console.log(data)
            for (let i = 0; i < data.length; i++) {
                let person =
                    {
                        id : data[i].o_id,
                        firstName: data[i].o_nom,
                        lastName: data[i].o_mobile,
                        gender: data[i].o_email,
                        genderr: data[i].o_date
                    }
                persons.push(person);
                personsOriginal = persons;
                drawTbl();
            }

            console.log("persons === ", persons)
        });


}

function drawTbl() {
    let tblBody = document.getElementById("tblBodyID");
    tblBody.innerHTML = "";
    let i = 0;
    persons.forEach(person => {
        let tr = document.createElement("tr")

        let idTD = document.createElement("td")
        idTD.innerText = person.id
        tr.appendChild(idTD);

        let firstNameTD = document.createElement("td")
        firstNameTD.innerText = person.firstName
        tr.appendChild(firstNameTD);

        let lastNameTD = document.createElement("td")
        lastNameTD.innerText = person.lastName
        tr.appendChild(lastNameTD);

        let genderTD = document.createElement("td")
        genderTD.innerText = person.gender
        tr.appendChild(genderTD)



        let actionsTD = document.createElement("td")
        actionsTD.innerHTML = `<button onclick="deleteTr(${i})"><i class="fas fa-trash fa-xs"></i></button>`;

        tr.appendChild(actionsTD);

        tblBody.appendChild(tr);
        i++;
    });
}

function search() {
    const motif = document.getElementById("searchID").value;

    if (motif) {
        persons = personsOriginal.filter((person) => {
                return person.firstName.toString().toUpperCase().includes(motif.toString().toUpperCase()) ||
                    person.lastName.toString().toUpperCase().includes(motif.toString().toUpperCase()) ||
                    person.gender.toString().toUpperCase().includes(motif.toString().toUpperCase()) ||
                    person.dateBirth.toString().toUpperCase().includes(motif.toString().toUpperCase())
            }
        );
    } else {
        persons = personsOriginal;
    }

    drawTbl();
}

function sort(key) {
    let sortedArr;
    sortDirection = !sortDirection;

    if (sortDirection) {
        sortedArr = persons.sort((a, b) =>
            a[key] < b[key] ? 1 : b[key] < a[key] ? -1 : 0
        );
    } else {
        sortedArr = persons.sort((a, b) =>
            a[key] > b[key] ? 1 : b[key] > a[key] ? -1 : 0
        );
    }
    persons = sortedArr;
    drawTbl();
}

async function deleteTr(index) {
    console.log(index)
    let response = confirm("Voulez vous vraiment supprimer cette planète?");

    if (response == true) {
        const response = await fetch(urlBe + "/" + persons[index].id, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        getPersons();
    }
}

async function enregistrer() {

    let firstName = document.getElementById("c_nom").value;
    let lastName = document.getElementById("c_mobile").value;
    let gender = document.getElementById("c_email").value;
    let method = 'POST';
    if(!Verifier_Numero_Telephone(lastName) == true)
    {
     alert('Numéro téléphone incorrect !');
     let lastName = document.getElementById("c_mobile").style.backgroundColor='red';
     return;
    }
    if(!validateEmail(gender)==true){
        alert('Email incorrect !');
        let gender=document.getElementById("c_email").style.backgroundColor='red';
        return;
    }
    let person =
        {
            e_nom: firstName,
            e_mobile: lastName,
            e_email: gender
        }
    if (currentIndex > -1) {
        method = 'PUT';
        urlBe = urlBe + "/" + persons[currentIndex].id;
    }

    const response = await fetch(urlBe, {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(person)
    });
    //const data = await response.json();
    resetForm();
    getPersons();
}
function updateTr(i) {
    currentIndex = i;
    let person = persons[i];
    console.log("cur person ... ", persons[currentIndex])
    document.getElementById("c_nom").value = person.firstName;
    document.getElementById("c_mobile").value = person.lastName;
    document.getElementById("c_email").value = person.gender;
}

function resetForm() {
    currentIndex = -1;
    document.getElementById("o_nom").value = "";
    document.getElementById("o_mobile").value = "";
    document.getElementById("o_email").value = "";
    document.getElementById("o_date").value = "";
}


function Verifier_Numero_Telephone(num_tel)
{
	// Definition du motif a matcher
	var regex = new RegExp(/^(2|3|4)[0-9]{7}/gi);
	// Definition de la variable booleene match
	var match = false;
	
	// Test sur le motif
	if(regex.test(num_tel))
	{
		match = true;
	}
	  else
	{
		match = false;
	}
	
	// On renvoie match
	return match;
}

function validateEmail(email) {
    let res = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    return res.test(email);
  }