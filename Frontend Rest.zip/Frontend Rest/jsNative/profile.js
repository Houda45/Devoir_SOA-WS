let farms = [];
let farmsOriginal = [];
let sortDirection = false;
let currentIndex = -1;
let urlBe = "http://localhost:8080/tp3Jpa/api/Admin";
getPersons();

//draw table then show async

async function getPersons() {
    persons = [];
    personsOriginal = [];
    let person=[];
    let urlBe = "http://localhost:8080/tp3Jpa/api/Admin";
    fetch(urlBe)
        .then(response => response.json())
        .then(data => {
            console.log(data)
            for (let i = 0; i < data.length; i++) {
    if(data[i].a_id==JSON.parse(localStorage.ok)){
                person =
                    {
                        id : data[i].a_id,
                        firstName: data[i].a_nom,
                        lastName: data[i].a_mobile,
                        gender: data[i].a_email,
                        genderr: data[i].a_username,
                        genderrr: data[i].a_password,
                        genderrrr: data[i].a_token
                    }
                } }
                persons.push(person);
                personsOriginal = persons;
                drawTbl();
            
       
            console.log("persons === ", persons)
        });


}

function drawTbl() {
    let tblBody = document.getElementById("oktov");
    tblBody.innerHTML = "";
    persons.forEach(person => {
        let div = document.createElement("div")

        let firstNameTD = document.createElement("h2")
        firstNameTD.innerText = person.firstName
        div.appendChild(firstNameTD);

        tblBody.appendChild(div);

    let cho=document.getElementById("chizyn");
    cho.innerHTML = "";
        srcimage=person.genderrrr

    let ok = document.createElement("div")

        let Image = document.createElement("img")
        Image.src =srcimage;
        Image.style="width: 120px;max-width: 100%;-webkit-border-radius: 50%;border-radius: 50%;-webkit-transition: -webkit-box-shadow 0.3s ease;transition: box-shadow 0.3s ease;-webkit-box-shadow: 0px 0px 0px 8px rgba(0, 0, 0, 0.06);box-shadow: 0px 0px 0px 8px rgba(0, 0, 0, 0.06);";
        ok.appendChild(Image);

        cho.appendChild(ok)
        
    });
}

function search() {
    const motif = document.getElementById("searchID").value;

    if (motif) {
        persons = personsOriginal.filter((person) => {
                return person.firstName.toString().toUpperCase().includes(motif.toString().toUpperCase()) ||
                    person.lastName.toString().toUpperCase().includes(motif.toString().toUpperCase()) ||
                    person.gender.toString().toUpperCase().includes(motif.toString().toUpperCase()) ||
                    person.dateBirth.toString().toUpperCase().includes(motif.toString().toUpperCase())
            }
        );
    } else {
        persons = personsOriginal;
    }

    drawTbl();
}

function sort(key) {
    let sortedArr;
    sortDirection = !sortDirection;

    if (sortDirection) {
        sortedArr = persons.sort((a, b) =>
            a[key] < b[key] ? 1 : b[key] < a[key] ? -1 : 0
        );
    } else {
        sortedArr = persons.sort((a, b) =>
            a[key] > b[key] ? 1 : b[key] > a[key] ? -1 : 0
        );
    }
    persons = sortedArr;
    drawTbl();
}

async function deleteTr(index) {
    console.log(index)
    let response = confirm("Voulez vous vraiment supprimer cette planète?");

    if (response == true) {
        const response = await fetch(urlBe + "/" + persons[index].id, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        getPersons()
    }
}

async function enregistrer() {

    let firstName = document.getElementById("m_nom").value;
    let lastName = document.getElementById("m_type").value;
    let gender = document.getElementById("m_desc").value;
    let genderr = document.getElementById("m_cost").value;
    let genderrr = document.getElementById("m_dose").value;
    let method = 'POST';
    let person =
        {
            m_nom: firstName,
            m_type: lastName,
            m_desc: gender,
            m_cost: genderr,
            m_dose: genderrr
        }
    if (currentIndex > -1) {
        method = 'PUT';
        urlBe = urlBe + "/" + persons[currentIndex].id;
    }

    const response = await fetch(urlBe, {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(person)
    });
    //const data = await response.json();
    resetForm();
    getPersons();
}

function updateTr(i) {
    currentIndex = i;
    let person = persons[i];
    console.log("cur person ... ", persons[currentIndex])

    document.getElementById("m_nom").value = person.firstName;
    document.getElementById("m_type").value = person.lastName;
    document.getElementById("m_desc").value = person.gender;
    document.getElementById("m_cost").value = person.genderr;
    document.getElementById("m_dose").value = person.genderrr;
}

function resetForm() {
    currentIndex = -1;
    document.getElementById("m_nom").value = "";
    document.getElementById("m_type").value = "";
    document.getElementById("m_desc").value = "";
    document.getElementById("m_cost").value = "";
    document.getElementById("m_dose").value = "";
}
