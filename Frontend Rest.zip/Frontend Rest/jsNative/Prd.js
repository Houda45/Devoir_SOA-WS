let farms = [];
let farmsOriginal = [];
let sortDirection = false;
let currentIndex = -1;
let urlBe = "http://localhost:8080/tp3Jpa/api/Admin/Produit";
getPersons();

//draw table then show async

async function getPersons() {
    persons = [];
    personsOriginal = [];
    let urlBe = "http://localhost:8080/tp3Jpa/api/Admin/Produit";
    fetch(urlBe)
        .then(response => response.json())
        .then(data => {
            console.log(data)
            for (let i = 0; i < data.length; i++) {
                let person =
                    {
                        id : data[i].p_id,
                        firstName: data[i].p_nom,
                        lastName: data[i].p_prix,
                        gender: data[i].p_quantite,
                        genderrrr: data[i].p_disponible,
                        genderrr: data[i].p_image,
                        genderr: data[i].p_desc
                    }
                persons.push(person);
                personsOriginal = persons;
                drawTbl();
            }

            console.log("persons === ", persons)
        });


}

function drawTbl() {
    let tblBody = document.getElementById("tblBodyID");
    tblBody.innerHTML = "";
    let i = 0;
    persons.forEach(person => {
        let tr = document.createElement("tr")

        let firstNameTD = document.createElement("td")
        firstNameTD.innerText = person.firstName
        tr.appendChild(firstNameTD);

        let lastNameTD = document.createElement("td")
        lastNameTD.innerText = person.lastName
        tr.appendChild(lastNameTD);

        let genderTD = document.createElement("td")
        genderTD.innerText = person.gender
        tr.appendChild(genderTD)

        let genderrTD = document.createElement("td")
        genderrTD.innerText = person.genderr
        tr.appendChild(genderrTD)

        
        let actionsTD = document.createElement("td")
        actionsTD.innerHTML = `<button onclick="updateTr(${i})"><i class="fas fa-pen fa-xs"></i></button>
                            <button onclick="deleteTr(${i})"><i class="fas fa-trash fa-xs"></i></button>`;

        tr.appendChild(actionsTD);

        tblBody.appendChild(tr);
        i++;
    });
}

function search() {
    const motif = document.getElementById("searchID").value;

    if (motif) {
        persons = personsOriginal.filter((person) => {
                return person.firstName.toString().toUpperCase().includes(motif.toString().toUpperCase()) ||
                    person.lastName.toString().toUpperCase().includes(motif.toString().toUpperCase()) ||
                    person.gender.toString().toUpperCase().includes(motif.toString().toUpperCase()) ||
                    person.genderr.toString().toUpperCase().includes(motif.toString().toUpperCase())
            }
        );
    } else {
        persons = personsOriginal;
    }

    drawTbl();
}

function sort(key) {
    let sortedArr;
    sortDirection = !sortDirection;

    if (sortDirection) {
        sortedArr = persons.sort((a, b) =>
            a[key] < b[key] ? 1 : b[key] < a[key] ? -1 : 0
        );
    } else {
        sortedArr = persons.sort((a, b) =>
            a[key] > b[key] ? 1 : b[key] > a[key] ? -1 : 0
        );
    }
    persons = sortedArr;
    drawTbl();
}

async function deleteTr(index) {
    console.log(index)
    let response = confirm("Voulez vous vraiment supprimer ce Produit?");

    if (response == true) {
        const response = await fetch(urlBe + "/" + persons[index].id, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        getPersons()
    }
}

async function enregistrer() {

    let firstName = document.getElementById("p_nom").value;
    let lastName = document.getElementById("p_prix").value;
    let genderrr = document.getElementById("p_image").files[0].name;
    let gender = document.getElementById("p_quantite").value;
    let genderrrr = document.getElementById("p_disponible").checked;
    let genderr=document.getElementById("p_desc").value
   
    
    
    let method = 'POST';
    let person =
        {
            p_nom: firstName,
            p_prix: lastName,
            p_image: genderrr,
            p_quantite: gender,
            p_disponible: genderrrr,
            p_desc: genderr

            
        }
    if (currentIndex > -1) {
        method = 'PUT';
        urlBe = urlBe + "/" + persons[currentIndex].id;
    }

    const response = await fetch(urlBe, {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(person)
    });
    //const data = await response.json();
    resetForm();
    getPersons();
}

function updateTr(i) {
    currentIndex = i;
    let person = persons[i];
    console.log("cur person ... ", persons[currentIndex])

    document.getElementById("p_nom").value = person.firstName;
    document.getElementById("p_prix").value = person.lastName;
    document.getElementById("p_quantite").value = person.gender;
    document.getElementById("p_disponible").value = person.genderr;
    document.getElementById("p_image").value = person.genderrr;
    document.getElementById("p_desc").value = person.genderrrr;
}

function resetForm() {
    currentIndex = -1;
    document.getElementById("p_nom").value = "";
    document.getElementById("p_prix").value = "";
    document.getElementById("p_quantite").value = "";
    document.getElementById("p_disponible").value = "";
    document.getElementById("p_image").value = "";
    document.getElementById("p_desc").value = "";
}


function createPDF() {
    var sTable = document.getElementById('myTable').innerHTML;

    var style = "<style>";
    style = style + "table {width: 100%;font: 17px Calibri;}";
    style = style + "table, th, td {border: solid 1px #DDD; border-collapse: collapse;";
    style = style + "padding: 2px 3px;text-align: center;}";
    style = style + "</style>";

    // CREATE A WINDOW OBJECT.
    var win = window.open('', '', 'height=700,width=700');

    win.document.write('<html><head>');
    win.document.write('<title>Profile</title>');   // <title> FOR PDF HEADER.
    win.document.write(style);          // ADD STYLE INSIDE THE HEAD TAG.
    win.document.write('</head>');
    win.document.write('<body>');
    win.document.write(sTable);         // THE TABLE CONTENTS INSIDE THE BODY TAG.
    win.document.write('</body></html>');

    win.document.close(); 	// CLOSE THE CURRENT WINDOW.

    win.print();    // PRINT THE CONTENTS.
}