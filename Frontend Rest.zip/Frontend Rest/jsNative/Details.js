
var str =window.location.href;
var url = new URL(str);
var idpage = url.searchParams.get("id");


let farms = [];
let farmsOriginal = [];
let sortDirection = false;
let currentIndex = -1;
let urlBe = "http://localhost:8080/tp3Jpa/api/Admin/Produit/"+idpage;
getPerson();


//draw table then show async

async function getPerson() {
    persons = [];
    personsOriginal = [];
    let urlBe = "http://localhost:8080/tp3Jpa/api/Admin/Produit/"+idpage;
    fetch(urlBe)
        .then(response => response.json())
        .then(data => {
            console.log(data)
            
                let person =
                    {
                        id : data.p_id,
                        firstName: data.p_nom,
                        lastName: data.p_prix,
                        genderrr: data.p_image,
                        gender: data.p_quantite,
                        genderr: data.p_disponible
                        
                    }
                persons.push(person);
                personsOriginal = persons;
                drawTbl();
                GFG_Run();
          

            console.log("persons === ", persons)
        });


}

function drawTbl() {
    let tblBody = document.getElementById("bo");
    tblBody.innerHTML = "";
    persons.forEach(person => {
        id=person.id;
        srcimage=person.genderrr;
        let div = document.createElement("div")
        div.className = 'column';
        let Nomlabel = document.createElement("label")
        Nomlabel.innerText = person.firstName
        div.appendChild(Nomlabel);
        let BR = document.createElement("BR")
        div.appendChild(BR);

        let Image = document.createElement("img")
        Image.src =srcimage;
        div.appendChild(Image);

        let B = document.createElement("BR")
        div.appendChild(B);

        const text = document.createTextNode("Prix: ");
        div.appendChild(text);
        
        let Prixlabel = document.createElement("label")
        Prixlabel.innerText = person.lastName
        div.appendChild(Prixlabel);
        const espace = document.createTextNode("MRO");
        espace.style="color:black";
        div.appendChild(espace);
    

        tblBody.appendChild(div);
    });
}
function GFG_Run() {
    persons.forEach(person => {
    document.getElementById("s_nom").value = person.firstName;
    document.getElementById("s_prix").value = person.lastName;
    document.getElementById("s_desc").value = person.gender;
    
    document.getElementById('s_nom').readOnly
            = true;
    document.getElementById('s_prix').readOnly
            = true;
    document.getElementById('s_desc').readOnly
            = true;
     
        });
}
var product=[];

function fun(){
  var x={};
  persons.forEach(person => {
  x.price= person.lastName;
  x.title=person.firstName;
  product.push(x);
    
  var iDiv = document.createElement('div');
  iDiv.id = product.length;
  iDiv.className = 'block';
  document.getElementsByTagName('body')[0].appendChild(iDiv);
  
  var para = document.createElement("span");
  var node = document.createTextNode('Title: ' + x.title+' |                    ');
  para.appendChild(node);

  var element = document.getElementById(product.length);
  element.appendChild(para);
  
  para = document.createElement("span");
  node = document.createTextNode('Price: '+ x.price);
  para.appendChild(node);
  
  element.appendChild(para);
});
}