package com.fst.master.dao;

import com.fst.master.entity.Commande;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.List;

public class CommandeDao {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("projetUnit");
    EntityManager em = emf.createEntityManager();

    public Commande add(Commande o) {
        em.getTransaction().begin();
        em.persist(o);
        em.getTransaction().commit();
        return o;
    }

    public Commande update(Commande o) {
        em.getTransaction().begin();
        em.merge(o);
        em.getTransaction().commit();
        return o;
    }

    public boolean remove(Commande o) {

        em.getTransaction().begin();

        em.remove(o);

        em.getTransaction().commit();
        return true;
    }

    public Commande getById(int o_id) {

        return em.find(Commande.class,o_id);

    }

    public List<Commande> getAll() {

        String sql = "select o from Commande o order by o.o_id desc ";

        TypedQuery<Commande> qr = em.createQuery(sql, Commande.class);

        return qr.getResultList();

    }
}
