package com.fst.master.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Client {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    int c_id;
    String c_nom;
    String c_prenom;
    String c_adresse;
    String c_mobile;
    String c_email;
    boolean c_statut;
    boolean c_active;
    String c_username;
    String c_password;

//    @ManyToMany
//    @JoinTable(name="Commande",
//            joinColumns=@JoinColumn(name="Client_ID"),
//            inverseJoinColumns=@JoinColumn(name="Commande_ID"))
//    public List<Commande> commandes;

    public Client(){
    }

    public Client(int c_id, String c_nom, String c_prenom, String c_adresse, String c_mobile, String c_email, boolean c_statut, boolean c_active, String c_username,  String c_password ){
        this.c_id=c_id;
        this.c_nom=c_nom;
        this.c_prenom=c_prenom;
        this.c_adresse=c_adresse;
        this.c_mobile=c_mobile;
        this.c_email=c_email;
        this.c_statut=c_statut;
        this.c_active=c_active;
        this.c_username=c_username;
        this.c_password=c_password;
    }

    public int getC_id() {
        return c_id;
    }

    public void setC_id(int c_id) {
        this.c_id = c_id;
    }

    public String getC_nom() {
        return c_nom;
    }

    public void setC_nom(String c_nom) {
        this.c_nom = c_nom;
    }

    public String getC_prenom() {
        return c_prenom;
    }

    public void setC_prenom(String c_prenom) {
        this.c_prenom = c_prenom;
    }

    public String getC_adresse() {
        return c_adresse;
    }

    public void setC_adresse(String c_adresse) {
        this.c_adresse = c_adresse;
    }

    public Boolean getC_statut() {
        return c_statut;
    }

    public void setC_statut(Boolean c_statut) {
        this.c_statut = c_statut;
    }

    public Boolean getC_active() {
        return c_active;
    }

    public void setC_active(Boolean c_active) {
        this.c_active = c_active;
    }

    public String getC_mobile() {
        return c_mobile;
    }

    public void setC_mobile(String c_mobile) {
        this.c_mobile = c_mobile;
    }

    public String getC_email() {
        return c_email;
    }

    public void setC_email(String c_email) {
        this.c_email = c_email;
    }

    public String getC_username() {
        return c_username;
    }

    public void setC_username(String c_username) {
        this.c_username = c_username;
    }

    public String getC_password() {
        return c_password;
    }

    public void setC_password(String c_password) {
        this.c_password = c_password;
    }
}



