package com.fst.master.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
public class Message {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    int m_id;
    String m_contenu;
    String m_date;

    public Message(int m_id, String m_contenu, String m_date) {
        this.m_id = m_id;
        this.m_contenu = m_contenu;
        this.m_date = m_date;
    }


    public Message(){

    }

    public int getM_id() {
        return m_id;
    }

    public void setM_id(int m_id) {
        this.m_id = m_id;
    }

    public String getM_contenu() {
        return m_contenu;
    }

    public void setM_nom(String m_contenu) {
        this.m_contenu = m_contenu;
    }

    public String getM_date() {
        return m_date;
    }

    public void setM_date(String m_date) {
        this.m_date = m_date;
    }


}
