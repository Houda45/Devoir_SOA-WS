package com.fst.master.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

@Entity
public class Commande {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    int o_id;
    String o_nom;
    String o_mobile;
    String o_email;
    String  o_date;

    public Commande(){};
    public Commande(int o_id, String o_nom, String o_mobile, String o_email, String o_date) {
        this.o_id=o_id;
        this.o_nom = o_nom;
        this.o_mobile = o_mobile;
        this.o_email = o_email;
        this.o_date = o_date;
    }

    public int getO_id() {
        return o_id;
    }

    public void setO_id(int o_id) {
        this.o_id = o_id;
    }

    public String getO_nom() {
        return o_nom;
    }

    public void setO_nom(String o_nom) {
        this.o_nom = o_nom;
    }

    public String getO_mobile() {
        return o_mobile;
    }

    public void setO_mobile(String o_mobile) {
        this.o_mobile = o_mobile;
    }

    public String getO_email() {
        return o_email;
    }

    public void setO_email(String o_email) {
        this.o_email = o_email;
    }

    public String getO_date() {
        return o_date;
    }

    public void setO_date(String o_date) {
        this.o_date = o_date;
    }
}
