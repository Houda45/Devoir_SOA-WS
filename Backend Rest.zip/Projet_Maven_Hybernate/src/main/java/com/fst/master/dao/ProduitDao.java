package com.fst.master.dao;


import com.fst.master.entity.Produit;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.List;

public class ProduitDao {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("projetUnit");
    EntityManager em = emf.createEntityManager();

    public Produit add(Produit p) {
        em.getTransaction().begin();
        em.persist(p);
        em.getTransaction().commit();
        return p;
    }

    public Produit update(Produit p) {
        em.getTransaction().begin();
        em.merge(p);
        em.getTransaction().commit();
        return p;
    }

    public boolean remove(Produit p) {

        em.getTransaction().begin();

        em.remove(p);

        em.getTransaction().commit();
        return true;
    }

    public Produit getById(int p_id) {

        return em.find(Produit.class,p_id);

    }

    public List<Produit> getAll() {

        String sql = "select p from Produit p order by p.p_id desc ";

        TypedQuery<Produit> qr = em.createQuery(sql, Produit.class);

        return qr.getResultList();

    }
}
