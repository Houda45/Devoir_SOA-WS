package com.fst.master.dao;


import com.fst.master.entity.Categorie;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.List;

public class CategorieDao {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("projetUnit");
    EntityManager em = emf.createEntityManager();

    public Categorie add(Categorie s) {
        em.getTransaction().begin();
        em.persist(s);
        em.getTransaction().commit();
        return s;
    }

    public Categorie update(Categorie s) {
        em.getTransaction().begin();
        em.merge(s);
        em.getTransaction().commit();
        return s;
    }

    public boolean remove(Categorie s) {

        em.getTransaction().begin();

        em.remove(s);

        em.getTransaction().commit();
        return true;
    }

    public Categorie getById(int s_id) {

        return em.find(Categorie.class,s_id);

    }

    public List<Categorie> getAll() {

        String sql = "select s from Categorie s order by s.s_id desc ";

        TypedQuery<Categorie> qr = em.createQuery(sql, Categorie.class);

        return qr.getResultList();

    }
}
