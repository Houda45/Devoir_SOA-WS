package com.fst.master.dao;

import com.fst.master.entity.Admin;
import com.fst.master.filter.PasswordHelper;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.List;

public class AdminDao {

    EntityManagerFactory emf = Persistence.createEntityManagerFactory("projetUnit");
    EntityManager em = emf.createEntityManager();

    public Admin add(Admin a) {
        em.getTransaction().begin();
        em.persist(a);
        em.getTransaction().commit();
        return a;
    }

    public Admin update(Admin a) {
        em.getTransaction().begin();
        em.merge(a);
        em.getTransaction().commit();
        return a;
    }

    public boolean remove(Admin a) {

        em.getTransaction().begin();

        em.remove(a);

        em.getTransaction().commit();
        return true;
    }

    public Admin getById(int a_id) {

        return em.find(Admin.class,a_id);

    }

    public List<Admin> getAll() {

        String sql = "select a from Admin a order by a.a_id desc ";

        TypedQuery<Admin> qr = em.createQuery(sql, Admin.class);

        return qr.getResultList();

    }

    public  boolean  authenticate(String a_username,String a_password)  {

        String sql = "select a from Admin a where a.a_username = '"+a_username+"'";
        TypedQuery<Admin> qr = em.createQuery(sql, Admin.class);
        List<Admin> admins = qr.getResultList();

        Admin admin = admins.get(0);
        if (admins.size() == 0 || !(PasswordHelper.check(a_password,admin.getA_password()))) {
            return false;
        }
        return true;
    }
}
