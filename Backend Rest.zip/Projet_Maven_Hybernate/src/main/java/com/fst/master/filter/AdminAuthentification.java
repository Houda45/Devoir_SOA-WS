
//
//import java.io.IOException;
//import java.io.PrintWriter;
//
//import javax.servlet.Filter;
//import javax.servlet.FilterChain;
//import javax.servlet.FilterConfig;
//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
//import javax.servlet.ServletRequest;
//import javax.servlet.ServletResponse;
//import javax.servlet.annotation.WebFilter;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;
//
//
//
//
///**
// * Servlet Filter implementation class AdminAuthentification
// */
//@WebFilter("/service/Admin")
//public class AdminAuthentification implements Filter {
//
//    /**
//     * Default constructor.
//     */
//    public AdminAuthentification() {
//        // TODO Auto-generated constructor stub
//    }
//
//    /**
//     * @see Filter#destroy()
//     */
//
//    public void destroy() {
//        // TODO Auto-generated method stub
//    }
//
//    /**
//     * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
//     */
//
//    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
//        response.setContentType("text/html");
//        PrintWriter printWriter=response.getWriter();
//        String a_username =request.getParameter("a_username");
//        String a_password=request.getParameter("a_password");
//        AdminDao adminDao = new AdminDao();
//        if (adminDao.authenticate(a_username, a_password)) {
//            HttpServletRequest httpRequest = (HttpServletRequest) request;
//            HttpSession session = httpRequest.getSession();
//            session.setAttribute("a_username", a_username);
//            session.setAttribute("a_password", a_password);
//            printWriter.println("welcome "+session.getAttribute("a_username")+ " to page administration ");
//        }
//        else
//        {
//
//            printWriter.println("vous navez pas l'acces verifier votre information");
//
//
//        }
//
//
//
//    }
//
//    /**
//     * @see Filter#init(FilterConfig)
//     */
//    public void init(FilterConfig fConfig) throws ServletException {
//        // TODO Auto-generated method stub
//    }
//
//}
