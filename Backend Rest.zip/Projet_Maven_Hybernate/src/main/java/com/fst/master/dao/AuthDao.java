package com.fst.master.dao;

import com.fst.master.entity.Admin;
import com.fst.master.filter.PasswordHelper;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.List;
import java.util.UUID;

public class AuthDao {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("projetUnit");
    EntityManager em = emf.createEntityManager();

    public  void  authenticate(String a_username,String a_password) throws Exception  {

        String sql = "select a from Admin a where a.a_username = '"+a_username+"'";
        TypedQuery<Admin> qr = em.createQuery(sql, Admin.class);
        List<Admin> admins = qr.getResultList();

        Admin admin = admins.get(0);
        if (admins.size() == 0 || !(PasswordHelper.check(a_password,admin.getA_password()))) {
            throw new Exception();
        }
    }
    public  Admin  generateToken(String a_username) throws Exception {
        String sql = "select a from Admin a where a.a_username = '"+a_username+"'";
        TypedQuery<Admin> qr = em.createQuery(sql, Admin.class);
        List<Admin> admins = qr.getResultList();
        String token = UUID.randomUUID().toString() + admins.get(0).getA_id();
        em.getTransaction().begin();

        Admin updateUser = em.find(Admin.class,admins.get(0).getA_id());
        if (updateUser.getA_token()==null){
            updateUser.setA_token(token);
            em.persist(updateUser);
            em.getTransaction().commit();
        }

        return updateUser;
    }

    public  Admin  userByToken(String a_token){
        String sql = "select a from Admin a where a.a_token = '"+a_token+"'";
        TypedQuery<Admin> qr = em.createQuery(sql, Admin.class);
        List<Admin> admins = qr.getResultList();
        Admin admin =null;
        if (admins.size() > 0) {
            admin = admins.get(0);
        }
        return admin;
    }
    public void removeToken(long id){
        Admin admin = em.find(Admin.class,id);
        em.getTransaction().begin();
        admin.setA_token(null);
        em.getTransaction().commit();

    }
}
