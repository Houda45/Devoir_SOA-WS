package com.fst.master.dao;

import com.fst.master.entity.CarteBancaire;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.List;

public class CarteBancaireDao {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("projetUnit");
    EntityManager em = emf.createEntityManager();

    public CarteBancaire add(CarteBancaire t) {
        em.getTransaction().begin();
        em.persist(t);
        em.getTransaction().commit();
        return t;
    }

    public CarteBancaire update(CarteBancaire t) {
        em.getTransaction().begin();
        em.merge(t);
        em.getTransaction().commit();
        return t;
    }

    public boolean remove(CarteBancaire t) {

        em.getTransaction().begin();

        em.remove(t);

        em.getTransaction().commit();
        return true;
    }

    public CarteBancaire getById(int t_id) {

        return em.find(CarteBancaire.class,t_id);

    }

    public List<CarteBancaire> getAll() {

        String sql = "select t from CarteBancaire t order by t.t_id desc ";

        TypedQuery<CarteBancaire> qr = em.createQuery(sql, CarteBancaire.class);

        return qr.getResultList();

    }
}
