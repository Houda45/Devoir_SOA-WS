package com.fst.master.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Produit {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    int p_id;
    String p_nom;
    int p_prix;
    int p_quantite;
    String p_image;
    String p_desc;
    Boolean p_disponible;

    public Produit(){}
    public Produit(int p_id, String p_nom, int p_prix, int p_quantite, String p_image, String p_desc, boolean p_disponible){
        this.p_id=p_id;
        this.p_nom=p_nom;
        this.p_prix=p_prix;
        this.p_quantite=p_quantite;
        this.p_image=p_image;
        this.p_desc=p_desc;
        this.p_disponible=p_disponible;
    }

    public int getP_id() {
        return p_id;
    }

    public void setP_id(int p_id) {
        this.p_id = p_id;
    }

    public String getP_nom() {
        return p_nom;
    }

    public void setP_nom(String p_nom) {
        this.p_nom = p_nom;
    }

    public int getP_prix() {
        return p_prix;
    }

    public void setP_prix(int p_prix) {
        this.p_prix = p_prix;
    }

    public int getP_quantite() {
        return p_quantite;
    }

    public void setP_quantite(int p_quantite) {
        this.p_quantite = p_quantite;
    }

    public String getP_image() {
        return p_image;
    }

    public void setP_image(String p_image) {
        this.p_image = p_image;
    }

    public String getP_desc() {
        return p_desc;
    }

    public void setP_desc(String p_desc) {
        this.p_desc = p_desc;
    }

    public Boolean getP_disponible() {return p_disponible;}

    public void setP_disponible(Boolean p_disponible) {
        this.p_disponible = p_disponible;
    }


}
