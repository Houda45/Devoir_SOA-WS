package com.fst.master.entity;

import javax.persistence.*;

@Entity
public class Panier {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    int p_id;
    String p_listeProduit;


    public Panier(int p_id, String p_listeProduit) {
        this.p_id = p_id;
        this.p_listeProduit = p_listeProduit;

    }
    public Panier(){

    }
    public int getP_id() {
        return p_id;
    }

    public void setP_id(int p_id) {
        this.p_id = p_id;
    }

    public String getP_listeProduit() {
        return p_listeProduit;
    }

    public void setP_listeProduit(String p_listeProduit) {
        this.p_listeProduit = p_listeProduit;
    }




}
