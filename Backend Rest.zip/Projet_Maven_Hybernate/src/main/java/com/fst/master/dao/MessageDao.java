package com.fst.master.dao;

import com.fst.master.entity.Message;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.List;

public class MessageDao {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("projetUnit");
    EntityManager em = emf.createEntityManager();

    public Message add(Message m) {
        em.getTransaction().begin();
        em.persist(m);
        em.getTransaction().commit();
        return m;
    }

    public Message update(Message m) {
        em.getTransaction().begin();
        em.merge(m);
        em.getTransaction().commit();
        return m;
    }

    public boolean remove(Message m) {

        em.getTransaction().begin();

        em.remove(m);

        em.getTransaction().commit();
        return true;
    }

    public Message getById(int m_id) {

        return em.find(Message.class,m_id);

    }

    public List<Message> getAll() {

        String sql = "select m from Message m order by m.m_id desc ";

        TypedQuery<Message> qr = em.createQuery(sql, Message.class);

        return qr.getResultList();

    }
}
