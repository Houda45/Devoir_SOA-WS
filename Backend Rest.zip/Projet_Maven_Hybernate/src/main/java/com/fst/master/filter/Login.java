
//import java.io.IOException;
//import java.io.PrintWriter;
//
//import javax.servlet.ServletException;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//import javax.ws.rs.core.Context;
//
//public class Login extends HttpServlet{
//    //	@Context HttpServletRequest req;
//    private void ini() {
//        // TODO Auto-generated method stub
//
//    }
//    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        HttpSession session = request.getSession();
//        PrintWriter out  =response.getWriter();
//        AdminDao adminDao = new AdminDao();
//        String a_username = request.getParameter("a_username");
//        String a_password = request.getParameter("a_password");
//        if(adminDao.authenticate(a_username , a_password)){
//            session.setAttribute("adminSession", a_username);
//            out.println("bienvenue dans votre programme Nom: "+session.getAttribute("adminSession"));
//        }else if(a_username.equals(" ") && a_password.equals(" ")){
//            out.println("ajouter les donnees");
//        }else{
//            out.println("username ou le mot de passe est incorrect !");
//        }
//
//    }
//}
