package com.fst.master.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class CarteBancaire {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    int t_id;
    int t_numero;
    String t_dateExpiration;
    String t_code;

    public CarteBancaire(int t_id, int t_numero, String t_dateExpiration, String t_code) {
        this.t_id = t_id;
        this.t_numero = t_numero;
        this.t_dateExpiration = t_dateExpiration;
        this.t_code=t_code;

    }

    public CarteBancaire(){

    }

    public int getT_id() {
        return t_id;
    }

    public void setT_id(int t_id) {
        this.t_id = t_id;
    }

    public int getT_numero() {
        return t_numero;
    }

    public void setT_numero(int t_numero) {
        this.t_numero = t_numero;
    }

    public String getT_dateExpiration() {return t_dateExpiration;
    }

    public void setT_type(String t_dateExpiration) {
        this.t_dateExpiration = t_dateExpiration;
    }

    public String getT_code() {
        return t_code;
    }

    public void setT_code(String t_code) {
        this.t_code = t_code;
    }


}
