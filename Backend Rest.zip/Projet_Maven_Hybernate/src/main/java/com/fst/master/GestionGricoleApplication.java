package com.fst.master;

import com.fst.master.filter.PasswordHelper;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

//on peut mettre cette annotation pour ne pas avoir à faire la configuration dans
// le web.xml
@ApplicationPath("/api")
public class GestionGricoleApplication extends Application {

    public static void main(String[] args) {
        //URL url = getClass().getResource("/main/webapp/resources/styles/some.css");

        System.out.println(PasswordHelper.check("hi","$2a$06$/rs4tjFXx7Zqudt3y/9PtOT/FMkLeVlcqO2esg3aDzLXg1LoQfKR2"));
    }


}
