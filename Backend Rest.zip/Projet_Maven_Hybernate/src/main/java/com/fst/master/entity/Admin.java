package com.fst.master.entity;

import com.fst.master.filter.PasswordHelper;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Admin {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    int a_id;
    String a_nom;
    String a_mobile;
    String a_email;
    String a_username;
    String a_password;
    String a_token;

    public Admin(){
    }

    public Admin(int a_id, String a_nom, String a_mobile, String a_email, String a_username, String a_password, String a_token){
        this.a_id=a_id;
        this.a_nom=a_nom;
        this.a_mobile=a_mobile;
        this.a_email=a_email;
        this.a_username=a_username;
        this.a_password=a_password;
        this.a_token=a_token;
    }

    public int getA_id() {
        return a_id;
    }

    public void setA_id(int a_id) {
        this.a_id = a_id;
    }

    public String getA_nom() {
        return a_nom;
    }

    public void setA_nom(String a_nom) {
        this.a_nom = a_nom;
    }

    public String getA_mobile() {
        return a_mobile;
    }

    public void setA_mobile(String a_mobile) {
        this.a_mobile = a_mobile;
    }

    public String getA_email() {
        return a_email;
    }

    public void setA_email(String a_email) {
        this.a_email = a_email;
    }

    public String getA_username() {
        return a_username;
    }

    public void setA_username(String a_username) {
        this.a_username = a_username;
    }

    public String getA_password() {
        return a_password;
    }

    public void setA_password(String a_password) {
        this.a_password = PasswordHelper.encrypt(a_password);
    }

    public void setA_token(String a_token) {
        this.a_token = a_token;
    }

    public String getA_token() {
        return a_token;
    }
}
