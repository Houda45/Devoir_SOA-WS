package com.fst.master.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Categorie {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    int s_id;
    String s_nom;

    public Categorie(int s_id, String s_nom){
        this.s_id=s_id;
        this.s_nom=s_nom;

    }
    public Categorie(){}

    public int getS_id() {
        return s_id;
    }

    public void setS_id(int s_id) {
        this.s_id = s_id;
    }

    public String getS_nom() {
        return s_nom;
    }

    public void setS_nom(String s_nom) {
        this.s_nom = s_nom;
    }


}
