package com.fst.master.dao;

import com.fst.master.entity.Client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.List;

public class ClientDao {

    EntityManagerFactory emf = Persistence.createEntityManagerFactory("projetUnit");
    EntityManager em = emf.createEntityManager();

    public Client add(Client c) {
        em.getTransaction().begin();
        em.persist(c);
        em.getTransaction().commit();
        return c;
    }

    public Client update(Client c) {
        em.getTransaction().begin();
        em.merge(c);
        em.getTransaction().commit();
        return c;
    }

    public boolean remove(Client c) {

        em.getTransaction().begin();

        em.remove(c);

        em.getTransaction().commit();
        return true;
    }

    public Client getById(int c_id) {

        return em.find(Client.class,c_id);

    }

    public List<Client> getAll() {

        String sql = "select c from Client c order by c.c_id desc ";

        TypedQuery<Client> qr = em.createQuery(sql, Client.class);

        return qr.getResultList();

    }
}

