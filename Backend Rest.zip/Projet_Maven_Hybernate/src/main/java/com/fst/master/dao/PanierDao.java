package com.fst.master.dao;

import com.fst.master.entity.Panier;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.List;

public class PanierDao {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("projetUnit");
    EntityManager em = emf.createEntityManager();

    public Panier add(Panier p) {
        em.getTransaction().begin();
        em.persist(p);
        em.getTransaction().commit();
        return p;
    }

    public Panier update(Panier p) {
        em.getTransaction().begin();
        em.merge(p);
        em.getTransaction().commit();
        return p;
    }

    public boolean remove(Panier p) {

        em.getTransaction().begin();

        em.remove(p);

        em.getTransaction().commit();
        return true;
    }

    public Panier getById(int p_id) {

        return em.find(Panier.class,p_id);

    }

    public List<Panier> getAll() {

        String sql = "select p from Panier p order by p.p_id desc ";

        TypedQuery<Panier> qr = em.createQuery(sql, Panier.class);

        return qr.getResultList();

    }
}
