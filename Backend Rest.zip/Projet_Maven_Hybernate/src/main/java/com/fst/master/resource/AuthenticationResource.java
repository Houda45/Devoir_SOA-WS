package com.fst.master.resource;

import com.fst.master.dao.AdminDao;
import com.fst.master.dao.AuthDao;
import com.fst.master.entity.Admin;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/auth")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
public class AuthenticationResource {
    AuthDao authDoa = new AuthDao();
    AdminDao adminDao =new AdminDao();

    @POST
    @Path("login")
    public Response authenticateUser(@FormParam("login") String login, @FormParam("password") String password) {

        try {

            // Authenticate the user
            authDoa.authenticate(login, password);

            // Issue a token for the user
            Admin userWithToken = authDoa.generateToken(login);

            // Return the token on the response
            return Response.status(Response.Status.OK).entity(userWithToken).build();

        } catch (Exception e) {
            System.out.println(" catch error ");
            e.printStackTrace();
            return Response.status(Response.Status.FORBIDDEN).build();
        }
    }
    @POST
    @Path("register")
    @Consumes(MediaType.APPLICATION_JSON)
    public Admin register(Admin user) {
        return  adminDao.add(user);
    }
    @GET
    @Path("/logout/{id}")
    public boolean logout(@PathParam("id") long id){
        authDoa.removeToken(id);
        return true;
    }



    @GET
    @Path("/{token}")
    public Admin getT(@PathParam("token") String token){

        return authDoa.userByToken(token);
    }
}
