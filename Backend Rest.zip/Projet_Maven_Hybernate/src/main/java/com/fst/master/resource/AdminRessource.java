package com.fst.master.resource;

import com.fst.master.dao.*;
import com.fst.master.entity.*;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("Admin")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class AdminRessource {
    AdminDao adminDao =new AdminDao();

    ClientDao clientDao=new ClientDao();

    PanierDao panierDao = new PanierDao();
    MessageDao messageDao = new MessageDao();
    CarteBancaireDao carteBancaireDao = new CarteBancaireDao();
    ProduitDao produitDao=new ProduitDao();

    CategorieDao categorieDao= new CategorieDao();
    CommandeDao commandeDao=new CommandeDao();

    //--------------------------------------------------Admin-----------------------------------------
    @GET
    public List<Admin> fetchAll() {
        return adminDao.getAll();
    }

    @GET
    @Path("{id}")
    public Admin getById(@PathParam("id") int id) {

        return adminDao.getById(id);
    }

    @POST
    public Admin add(Admin a) {
        return adminDao.add(a);
    }

    @PUT
    @Path("{id}")
    public Admin update(Admin a, @PathParam("id") int id) {
        a.setA_id(id);
        return adminDao.update(a);

    }

    @DELETE
    @Path("{id}")
    public boolean delete(@PathParam("id") int id) {
        return adminDao.remove(adminDao.getById(id));
    }


    //----------------------------------------------Panier---------------------------------------------------
    @GET
    @Path("Panier")
    public List<Panier> fetchAllPanier() {
        return panierDao.getAll();
    }

    @GET
    @Path("Panier/{id}")
    public Panier getByIdPanier(@PathParam("id") int id) {

        return panierDao.getById(id);
    }

    @POST
    @Path("Panier")
    public Panier add(Panier p) {
        return panierDao.add(p);
    }

    @PUT
    @Path("Panier/{id}")
    public Panier updatePanier(Panier p, @PathParam("id") int id) {
        p.setP_id(id);
        return panierDao.update(p);

    }

    @DELETE
    @Path("Panier/{id}")
    public boolean deletePanier(@PathParam("id") int id) {
        return panierDao.remove(panierDao.getById(id));
    }

    //--------------------------------------------Message-----------------------------------------
    @GET
    @Path("Message")
    public List<Message> fetchAllMessage() {
        return messageDao.getAll();
    }

    @GET
    @Path("Message/{id}")
    public Message getByIdMessage(@PathParam("id") int id) {

        return messageDao.getById(id);
    }

    @POST
    @Path("Message")
    public Message add(Message m) {
        return messageDao.add(m);
    }

    @PUT
    @Path("Message/{id}")
    public Message updateMessage(Message m, @PathParam("id") int id) {
        m.setM_id(id);
        return messageDao.update(m);

    }

    @DELETE
    @Path("Message/{id}")
    public boolean deleteMessage(@PathParam("id") int id) {
        return messageDao.remove(messageDao.getById(id));
    }

    //---------------------------------------------CarteBancaire-----------------------------------------------
    @GET
    @Path("CarteBancaire")
    public List<CarteBancaire> fetchAllCarteBancaire() {
        return carteBancaireDao.getAll();
    }

    @GET
    @Path("CarteBancaire/{id}")
    public CarteBancaire getByIdCarteBancaire(@PathParam("id") int id) {

        return carteBancaireDao.getById(id);
    }

    @POST
    @Path("CarteBancaie")
    public CarteBancaire add(CarteBancaire t) {
        return carteBancaireDao.add(t);
    }

    @PUT
    @Path("CarteBancaire/{id}")
    public CarteBancaire updateCarteBancaire(CarteBancaire t, @PathParam("id") int id) {
        t.setT_id(id);
        return carteBancaireDao.update(t);

    }

    @DELETE
    @Path("CarteBancaire/{id}")
    public boolean deleteCarteBancaire(@PathParam("id") int id) {
        return carteBancaireDao.remove(carteBancaireDao.getById(id));
    }
    //-------------------------------------------------Client-----------------------------------------
    @GET
    @Path("Client")
    public List<Client> fetchAllClient() {
        return clientDao.getAll();
    }

    @GET
    @Path("Client/{id}")
    public Client getByIdClient(@PathParam("id") int id) {

        return clientDao.getById(id);
    }

    @POST
    @Path("Client")
    public Client add(Client c) {
        return clientDao.add(c);
    }

    @PUT
    @Path("Client/{id}")
    public Client updateClient(Client c, @PathParam("id") int id) {
        c.setC_id(id);
        return clientDao.update(c);

    }

    @DELETE
    @Path("Client/{id}")
    public boolean deleteClient(@PathParam("id") int id) {
        return clientDao.remove(clientDao.getById(id));
    }


    //-------------------------------------------------Categorie-----------------------------------------
    @GET
    @Path("Categorie")
    public List<Categorie> fetchAllCategorie() {
        return categorieDao.getAll();
    }

    @GET
    @Path("Categorie/{id}")
    public Categorie getByIdCategorie(@PathParam("id") int id) {

        return categorieDao.getById(id);
    }

    @POST
    @Path("Categorie")
    public Categorie add(Categorie s) {
        return categorieDao.add(s);
    }

    @PUT
    @Path("Categorie/{id}")
    public Categorie updateCategorie(Categorie s, @PathParam("id") int id) {
        s.setS_id(id);
        return categorieDao.update(s);

    }

    @DELETE
    @Path("Categorie/{id}")
    public boolean deleteCategorie(@PathParam("id") int id) {
        return categorieDao.remove(categorieDao.getById(id));
    }

    //----------------------------------------------Produit---------------------------------------------------
    @GET
    @Path("Produit")
    public List<Produit> fetchAllProduit() {
        return produitDao.getAll();
    }

    @GET
    @Path("Produit/{id}")
    public Produit getByIdProduit(@PathParam("id") int id) {

        return produitDao.getById(id);
    }

    @POST
    @Path("Produit")
    public Produit addProduit(Produit p) {
        return produitDao.add(p);
    }

    @PUT
    @Path("Produit/{id}")
    public Produit updateProduit(Produit p, @PathParam("id") int id) {
        p.setP_id(id);
        return produitDao.update(p);

    }

    @DELETE
    @Path("Produit/{id}")
    public boolean deleteProduit(@PathParam("id") int id) {
        return produitDao.remove(produitDao.getById(id));
    }

    //----------------------------------------------Commande---------------------------------------------------
    @GET
    @Path("Commande")
    public List<Commande> fetchAllCommande() {
        return commandeDao.getAll();
    }

    @GET
    @Path("Commande/{id}")
    public Commande getByIdCommande(@PathParam("id") int id) {

        return commandeDao.getById(id);
    }

    @POST
    @Path("Commande")
    public Commande addCommande(Commande o) {
        return commandeDao.add(o);
    }

    @PUT
    @Path("Commande/{id}")
    public Commande updateCommande(Commande o, @PathParam("id") int id) {
        o.setO_id(id);
        return commandeDao.update(o);

    }

    @DELETE
    @Path("Commande/{id}")
    public boolean deleteCommande(@PathParam("id") int id) {
        return commandeDao.remove(commandeDao.getById(id));
    }


}
